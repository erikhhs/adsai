def print_hi():
    print('hi')

def col_to_list(df,col):
    l = list(df[col])
    return l